function validateForm() {

    const idsach = document.getElementById("idsach").value.trim();
    const tensach = document.getElementById("tensach").value.trim();
    const tacgia = document.getElementById("tacgia").value.trim();
    const uutien = document.getElementById("uutien").value.trim();

    if (!idsach || !tensach || !tacgia || !gia || !uutien) {
        alert("Vui lòng nhập đầy đủ thông tin");
        return;
    }

    if (idsach.length > 10) {
        alert("Id sách tối đa 10 ký tự");
        return false;
    }

    if (tensach.length > 30) {
        alert("Tên sách tối đa 30 ký tự");
        return false;
    }

    if (tacgia.length > 50) {
        alert("Tác giả tối đa 50 ký tự");
        return false;
    }

    if (uutien !== "1" && uutien !== "2") {
        alert("Ưu tiên chỉ được nhập 1 hoặc 2");
        return false;
    }

    return true;
}

