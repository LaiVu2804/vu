package com.example.demo.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.demo.entity.Book;
import com.example.demo.service.BookService;

import jakarta.validation.Valid;

@Controller
public class BookController {

	private final BookService bookService;

	private BookController(BookService bookService) {
		this.bookService = bookService;
	}

	// Trang chu
	@RequestMapping("/home")
	public String getHomePage(Model model) {

		List<Book> arrBooks = this.bookService.getAllBooks();
		model.addAttribute("books", arrBooks);

		return "hello";
	}

	// Tao moi
	@RequestMapping("/create/books")
	public String AddBooks(Model model) {
		model.addAttribute("newBook", new Book());

		return "html/add";
	}

	@RequestMapping(value = "/create/books", method = RequestMethod.POST)
	public String getALLBooks(Model model, @Valid @ModelAttribute("newBook") Book book) {

		if (book.getUuTien() == null || book.getGia() == null || book.getIdsach() == null
				|| book.getTacgia() == null || book.getTensach() == null) {
			model.addAttribute("error", "Tạo thất bại do chưa nhập đủ thông tin !");
			return "html/add";
		}
		//Check id sach neu da ton tai
		if (this.bookService.checkExist(book.getIdsach())) {
			// Ném thông báo lỗi về trang tạo mới
			model.addAttribute("error", " ID sách '" + book.getIdsach() + "' đã tồn tại !");
			return "html/add";
		}
		
		this.bookService.saveBooks(book);

		return "redirect:/home?status=success&idsach=" + book.getIdsach();
	}
	
	// Cap nhat sach theo id
		@RequestMapping("/update/books/{idsach}")
		public String UpdateBooks(Model model, @PathVariable String idsach) {
			Book currentBook = bookService.getBookById(idsach)
					.orElseThrow(() -> new RuntimeException("Không tìm thấy idsach !" + idsach));
			model.addAttribute("newBook", currentBook);

			return "html/update";
		}

		@PostMapping("/update/books/{idsach}")
		public String updateBooks(Model model, @ModelAttribute("newBook") Book laivu) {
			Book currentBook = bookService.getBookById(laivu.getIdsach())
					.orElseThrow(() -> new RuntimeException("Không tìm thấy idsach !"));
			if (currentBook != null) {
				currentBook.setTensach(laivu.getTensach());
				currentBook.setTacgia(laivu.getTacgia());
				currentBook.setGia(laivu.getGia());
				currentBook.setUuTien(laivu.getUuTien());
				this.bookService.handleSaveBook(laivu);
			}

			return "redirect:/home";
		}
		
		// Xoa sach theo id
		@GetMapping("/delete/books/{idsach}")
		public String DeleteBooks(Model model, @PathVariable String idsach) {
			model.addAttribute("idsach", idsach);
			model.addAttribute("newBook", new Book());

			return "html/delete";
		}

		@PostMapping("/delete/books/{idsach}")
		public String postDeleteBooks(Model model, @ModelAttribute("newBook") Book laivu) {
			model.addAttribute("idsach", laivu);
			this.bookService.deleteBook(laivu.getIdsach());

			return "redirect:/home";
		}
}
