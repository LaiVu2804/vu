package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Book;
import com.example.demo.repository.BookRepository;

@Service
public class BookService {

	private final BookRepository bookRepository;

	public BookService(BookRepository bookRepository) {
		this.bookRepository = bookRepository;
	}

	public Book saveBooks(Book book) {
		return this.bookRepository.save(book);
	}

	public List<Book> getAllBooks() {
		return bookRepository.findAll();
	}

	public Optional<Book> getBookById(String idsach) {
	    return bookRepository.findById(idsach);
	}
	
	public Book handleSaveBook(Book book) {
		Book laivu = this.bookRepository.save(book);
		return laivu;
	}
	
	public void deleteBook(String idsach) {
	    bookRepository.deleteById(idsach);
	  }

	public boolean checkExist(String id) {
	    return bookRepository.existsByIdsach(id);
	}
}
