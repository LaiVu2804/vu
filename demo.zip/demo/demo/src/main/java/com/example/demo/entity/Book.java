package com.example.demo.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;

@Entity
@Table(name = "books")
public class Book {

	@Id
	@Column(length = 10)
	private String idsach;

	@Column(columnDefinition = "NVARCHAR(30)")
	private String tensach;

	@Column(columnDefinition = "NVARCHAR(50)")
	private String tacgia;

	@Column
	private Double gia;

	@Min(1)
	@Max(2)
	@JsonProperty("uuTien")
	private Integer uuTien;
	
	@Override
	public String toString() {
		return "Book [idsach=" + idsach + ", tensach=" + tensach + ", tacgia=" + tacgia + ", gia=" + gia + ", uuTien="
				+ uuTien + "]";
	}

	public Book() {

	}

	public String getIdsach() {
		return idsach;
	}

	public void setIdsach(String idsach) {
		this.idsach = idsach;
	}

	public String getTensach() {
		return tensach;
	}

	public void setTensach(String tensach) {
		this.tensach = tensach;
	}

	public String getTacgia() {
		return tacgia;
	}

	public void setTacgia(String tacgia) {
		this.tacgia = tacgia;
	}

	public Double getGia() {
		return gia;
	}

	public void setGia(Double gia) {
		this.gia = gia;
	}

	public Integer getUuTien() {
		return uuTien;
	}

	public void setUuTien(Integer uuTien) {
		this.uuTien = uuTien;
	}	
}
